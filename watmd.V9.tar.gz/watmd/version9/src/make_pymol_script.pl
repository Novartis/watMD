#!/usr/bin/perl -w
#creating pml file from watmd analysis
#Author Date Modification
#Andrei A Golosov 04/20 Created
#Andrei A Golosov 05/20 Modified for new version of pymol

use Getopt::Std;
use vars qw($opt_h $opt_H);
getopts('hH');
$prog_name = `basename $0`; chomp($prog_name);
$usage = "Description produces watmd.pml files\nusage: $prog_name <watmd_ALL.pdb>\n$prog_name -h or $prog_name -H for help; note that headers should match the name of the file (also could use Super_) i.e. system_PRO etc)\nExample:\n$prog_name system_ALL.pdb\n$prog_name Super_system_ALL.pdb\n"; 
if ($opt_h || $opt_H || $#ARGV < 0) {
  print $usage;
  exit 0;
};
foreach $file (@ARGV) {
  chomp($file);
  $fl=`basename $file _ALL.pdb`; chomp($fl); 
  $fl =~ s/Super_//;
  if (-e "$file") {
  print "processing $fl\n";
  open(OUT,">Super_$fl.watmd.pml") || die "could not open $fl.watmd.pml\n";
  print OUT "
load $file 
spectrum b, rainbow, ${fl}_GRO
spectrum b, rainbow, ${fl}_SUR
spectrum q, red_white_blue, ${fl}_CVX
alter ${fl}_CVX, vdw=b/10
create ${fl}_HOT, ${fl}_CVX and b>2 
create ${fl}_COMBODIPOLES, ${fl}_DIPOLE*
color blue, ${fl}_COMBODIPOLES///DIP`*/Na
color red, ${fl}_COMBODIPOLES///DIP`*/Cl
delete ${fl}_DIPOLE_*
delete ${fl}_DHWP
delete ${fl}_DHWN
orient ${fl}_PRO and resn UNK

hide everything
show lines
show cartoon

show sticks, organic and ${fl}_PRO
show spheres, ${fl}_HOT
color yellow, elem C and resn UNK 

#remove edge box
remove resn SUR and resi 1

";
  close(OUT);
  }
  else {
    print "not ready: $fl\n";
  }
}

