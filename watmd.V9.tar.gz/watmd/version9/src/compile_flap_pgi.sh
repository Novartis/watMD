#!/bin/sh
cd ./flap/src
./make_flap_pgi.sh



