
pgfortran  -cpp -c -Mallocatable=03  -i8 -fast  -module ../static/mod face.F03 
pgfortran  -cpp -c -Mallocatable=03  -i8 -fast  -module ../static/mod penf_global_parameters_variables_pgi.F03
pgfortran  -cpp -c -Mallocatable=03  -i8 -fast  -module ../static/mod penf_b_size.F03
pgfortran  -cpp -c -Mallocatable=03  -i8 -fast  -module ../static/mod penf_stringify.F03
pgfortran  -cpp -c -Mallocatable=03  -i8 -fast  -module ../static/mod penf.F03
pgfortran  -cpp -c -Mallocatable=03  -i8 -fast  -module ../static/mod flap_object_t.f90
pgfortran  -cpp -c -Mallocatable=03  -i8 -fast  -module ../static/mod flap_utils_m.f90 
pgfortran  -cpp -c -Mallocatable=03  -i8 -fast  -module ../static/mod flap_command_line_argument_t.F03  
pgfortran  -cpp -c -Mallocatable=03  -i8 -fast  -module ../static/mod flap_command_line_arguments_group_t_pgi.f90 
pgfortran  -cpp -c -Mallocatable=03  -i8 -fast  -module ../static/mod flap_command_line_interface_t.F03 
pgfortran  -cpp -c -Mallocatable=03  -i8 -fast  -module ../static/mod flap.f90

ar rv ../static/libflap.a *.o



