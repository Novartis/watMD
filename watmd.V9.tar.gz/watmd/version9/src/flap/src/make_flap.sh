
ifort  -cpp -c -assume realloc_lhs  -i8 -O2 -D_R16P_SUPPORTED -module ../static/mod face.F90 
ifort  -cpp -c -assume realloc_lhs  -i8 -O2 -D_R16P_SUPPORTED -module ../static/mod penf_global_parameters_variables.F90
ifort  -cpp -c -assume realloc_lhs  -i8 -O2 -D_R16P_SUPPORTED -module ../static/mod penf_b_size.F90
ifort  -cpp -c -assume realloc_lhs  -i8 -O2 -D_R16P_SUPPORTED -module ../static/mod penf_stringify.F90
ifort  -cpp -c -assume realloc_lhs  -i8 -O2 -D_R16P_SUPPORTED -module ../static/mod penf.F90
ifort  -cpp -c -assume realloc_lhs  -i8 -O2 -D_R16P_SUPPORTED -module ../static/mod flap_object_t.f90
ifort  -cpp -c -assume realloc_lhs  -i8 -O2 -D_R16P_SUPPORTED -module ../static/mod flap_utils_m.f90 
ifort  -cpp -c -assume realloc_lhs  -i8 -O2 -D_R16P_SUPPORTED -module ../static/mod flap_command_line_argument_t.F90  
ifort  -cpp -c -assume realloc_lhs  -i8 -O2 -D_R16P_SUPPORTED -module ../static/mod flap_command_line_arguments_group_t.f90 
ifort  -cpp -c -assume realloc_lhs  -i8 -O2 -D_R16P_SUPPORTED -module ../static/mod flap_command_line_interface_t.F90 
ifort  -cpp -c -assume realloc_lhs  -i8 -O2 -D_R16P_SUPPORTED -module ../static/mod flap.f90

ar rv ../static/libflap.a *.o



